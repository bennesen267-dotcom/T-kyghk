package com.bereton.mixin;

import com.bereton.BeretonClient;
import com.bereton.modules.combat.Aura;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayerEntity.class)
public class MixinClientPlayerEntity {

    @Unique
    private float bereton$savedYaw = Float.NaN;

    /** Hareket hesabından önce yaw'ı geçici olarak hedef yönüne çevirir. */
    @Inject(method = "tickMovement", at = @At("HEAD"))
    private void bereton$onTickMovementHead(CallbackInfo ci) {
        bereton$savedYaw = Float.NaN;
        if (BeretonClient.moduleManager == null) return;
        Aura aura = BeretonClient.moduleManager.aura;
        if (!aura.isEnabled() || !aura.track.isEnabled()) {
            Aura.clearDesiredMoveYaw();
            return;
        }
        float desiredYaw = Aura.getDesiredMoveYaw();
        if (Float.isNaN(desiredYaw)) return;

        ClientPlayerEntity self = (ClientPlayerEntity) (Object) this;
        bereton$savedYaw = self.getYaw();
        self.setYaw(desiredYaw);
        Aura.clearDesiredMoveYaw();
    }

    /** Hareket bittikten sonra kamera yaw'ını geri yükler (kamera sabit kalır). */
    @Inject(method = "tickMovement", at = @At("RETURN"))
    private void bereton$onTickMovementReturn(CallbackInfo ci) {
        if (Float.isNaN(bereton$savedYaw)) return;
        ((ClientPlayerEntity) (Object) this).setYaw(bereton$savedYaw);
        bereton$savedYaw = Float.NaN;
    }
}
