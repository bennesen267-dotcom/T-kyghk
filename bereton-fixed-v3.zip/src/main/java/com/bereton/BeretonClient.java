package com.bereton;

import com.bereton.gui.ClickGUI;
import com.bereton.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class BeretonClient implements ClientModInitializer {

    public static BeretonClient INSTANCE;
    public static ModuleManager moduleManager;
    public static ClickGUI clickGUI;

    private static boolean shiftWasDown = false;

    @Override
    public void onInitializeClient() {
        INSTANCE = this;

        moduleManager = new ModuleManager();
        moduleManager.init();

        clickGUI = new ClickGUI();

        // Right Shift ile menüyü aç (doğrudan GLFW tuş durumu, edge detection ile).
        // Menü açıkken kapatma işi ClickGUI.keyPressed içinde yapılır, çünkü
        // ekran açıkken oyun tuş eventleri tick'e düşmez.
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.getWindow() == null) return;
            boolean down = InputUtil.isKeyPressed(client.getWindow().getHandle(), GLFW.GLFW_KEY_RIGHT_SHIFT);
            if (down && !shiftWasDown && client.currentScreen == null) {
                client.setScreen(clickGUI);
            }
            shiftWasDown = down;
        });
    }

    public static MinecraftClient mc() {
        return MinecraftClient.getInstance();
    }
}
