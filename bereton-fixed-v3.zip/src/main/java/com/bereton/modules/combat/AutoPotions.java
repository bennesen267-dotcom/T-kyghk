package com.bereton.modules.combat;

import com.bereton.BeretonClient;
import com.bereton.module.Category;
import com.bereton.module.Module;
import com.bereton.module.settings.BooleanSetting;
import com.bereton.module.settings.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SplashPotionItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.potion.Potion;
import net.minecraft.util.Hand;

public class AutoPotions extends Module {

    public final BooleanSetting speed =
            register(new BooleanSetting("Speed", true));
    public final BooleanSetting strength =
            register(new BooleanSetting("Strength", true));
    public final BooleanSetting regen =
            register(new BooleanSetting("Regeneration", true));
    public final BooleanSetting instantHeal =
            register(new BooleanSetting("Instant Heal", true));

    public final NumberSetting healThreshold =
            register(new NumberSetting("Heal Health", 12.0, 1.0, 20.0, 0.5));

    private int throwCooldown = 0;
    private static final int THROW_DELAY = 5;

    public AutoPotions() {
        super("Auto Potions", Category.COMBAT);
    }

    @Override
    public void onTick() {
        MinecraftClient mc = BeretonClient.mc();
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if (mc.currentScreen != null) return;
        ClientPlayerEntity player = mc.player;

        if (throwCooldown > 0) { throwCooldown--; return; }

        if (instantHeal.isEnabled() && player.getHealth() < healThreshold.getValue()) {
            if (tryThrow(mc, player, "healing")) return;
        }
        if (regen.isEnabled() && !player.hasStatusEffect(StatusEffects.REGENERATION)) {
            if (tryThrow(mc, player, "regeneration")) return;
        }
        if (speed.isEnabled() && !player.hasStatusEffect(StatusEffects.SPEED)) {
            if (tryThrow(mc, player, "swiftness")) return;
        }
        if (strength.isEnabled() && !player.hasStatusEffect(StatusEffects.STRENGTH)) {
            if (tryThrow(mc, player, "strength")) return;
        }
    }

    private boolean tryThrow(MinecraftClient mc, ClientPlayerEntity player, String potionName) {
        int slot = findSplashPotion(player, potionName);
        if (slot == -1) return false;

        int prevSlot = player.getInventory().selectedSlot;
        player.getInventory().selectedSlot = slot;

        float prevPitch = player.getPitch();
        player.setPitch(85.0f);
        mc.interactionManager.interactItem(player, Hand.MAIN_HAND);
        player.setPitch(prevPitch);

        player.getInventory().selectedSlot = prevSlot;
        throwCooldown = THROW_DELAY;
        return true;
    }

    private int findSplashPotion(ClientPlayerEntity player, String potionName) {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = player.getInventory().getStack(i);
            if (stack.isEmpty()) continue;
            if (!(stack.getItem() instanceof SplashPotionItem)) continue;

            PotionContentsComponent contents = stack.get(DataComponentTypes.POTION_CONTENTS);
            if (contents == null || contents.potion().isEmpty()) continue;

            // 1.21.4: contents.potion() returns Optional<RegistryEntry<Potion>>
            // RegistryEntry<Potion>.value() gives the Potion instance for getId()
            RegistryEntry<Potion> entry = contents.potion().get();
            String id = Registries.POTION.getId(entry.value()).getPath();

            if (id.contains(potionName)) return i;
        }
        return -1;
    }
}
