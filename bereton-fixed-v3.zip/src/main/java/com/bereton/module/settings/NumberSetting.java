package com.bereton.module.settings;

public class NumberSetting extends Setting<Double> {

    public final double min;
    public final double max;
    public final double step;

    public NumberSetting(String name, double defaultValue, double min, double max, double step) {
        super(name, defaultValue);
        this.min = min;
        this.max = max;
        this.step = step;
    }

    @Override
    public void setValue(Double value) {
        double snapped = min + Math.round((value - min) / step) * step;
        this.value = Math.max(min, Math.min(max, Math.round(snapped * 1000.0) / 1000.0));
    }

    public float getFloat() { return value.floatValue(); }
    public int   getInt()   { return value.intValue(); }
}
