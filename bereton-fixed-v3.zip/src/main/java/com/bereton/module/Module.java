package com.bereton.module;

import com.bereton.module.settings.Setting;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {

    public final String name;
    public final Category category;
    private boolean enabled = false;
    public final List<Setting<?>> settings = new ArrayList<>();

    public Module(String name, Category category) {
        this.name = name;
        this.category = category;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        boolean prev = this.enabled;
        this.enabled = enabled;
        if (!prev && enabled) onEnable();
        if (prev && !enabled) onDisable();
    }

    public void toggle() {
        setEnabled(!enabled);
    }

    // Called every client tick while enabled
    public void onTick() {}

    protected void onEnable() {}
    protected void onDisable() {}

    protected <T extends Setting<?>> T register(T setting) {
        settings.add(setting);
        return setting;
    }
}
